﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DATA.Domain.Migrations
{
    public partial class autoincrement2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
